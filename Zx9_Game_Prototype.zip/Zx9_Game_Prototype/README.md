# ZX9 — 3D Action Game Prototype

This is a first playable prototype: a 3D arena, player movement, enemy bots, attack, dash, health, score, waves, and touch controls.

## Quick test on a computer
1. Install Node.js LTS from https://nodejs.org/
2. Extract this ZIP.
3. Open a terminal/command prompt inside the extracted `Zx9_Game_Prototype` folder.
4. Run:
   ```bash
   npm install
   npm run start
   ```
5. Open the local URL printed by Vite. For phone testing, the phone and computer should be on the same Wi-Fi; use the Network URL Vite prints.

## Build an Android APK
Requirements: a computer, Node.js LTS, and Android Studio with Android SDK installed.
1. In the project folder run `npm install`.
2. Run `npm run build`.
3. Run `npx cap add android` (only once).
4. Run `npx cap sync android`.
5. Run `npx cap open android`.
6. In Android Studio, wait for Gradle sync to finish.
7. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
8. When it finishes, click **locate** in the notification. The debug APK is usually in `android/app/build/outputs/apk/debug/app-debug.apk`.
9. Copy the APK to your Android phone and tap it to install. If Android asks, allow installing apps from that source.

## Important
- Three.js is imported as a package and Vite bundles it into the build, so the built game does not need to fetch the 3D engine from a CDN.
- Android Studio/APK building requires a computer. If you only have your phone, you can test the browser version first; a cloud build service is another option, but setup differs.
- This is an early prototype. Add sound, missions, menus, and more polished animations in later versions.
